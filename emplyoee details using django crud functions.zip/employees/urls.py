from django.urls import path

from employees import views

urlpatterns = [

    path('',views.index),

    path('show',views.show,name="Display Emplyoee List"),

    path('edit/<int:id>',views.edit,name="Edit Emplyoee List"),

    path('update/<int:id>',views.update,name="Update"),

    path('delete/<int:id>',views.destroy,name="Delete Emplyoee record"),

]
