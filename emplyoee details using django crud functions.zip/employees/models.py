from django.db import models

# Create your models here.
class Employee(models.Model):
    objects = None
    name=models.CharField(max_length=255)
    age=models.IntegerField()
    empid=models.IntegerField()
    department=models.TextField()

'''def __str__(self):
    return str(self.name) + " " + str(self.email)
    '''
class meta:
        db_table='employees'