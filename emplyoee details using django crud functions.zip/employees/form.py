from django import forms
#import model class from models.py
#from app_name.models import model_name
from employees.models import Employee



class EmployeeForm(forms.ModelForm):
    class Meta:
        model=Employee
        fields="__all__"
