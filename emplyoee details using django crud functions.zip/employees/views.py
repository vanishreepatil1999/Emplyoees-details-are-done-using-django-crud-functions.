from django.shortcuts import render

# Create your views here.
from django.shortcuts import render,HttpResponse,redirect
#loading StudentForm from form.py inside students app
#from app_name.form import ModelForm_name
from employees.form import EmployeeForm
from employees.models import Employee

# Create your views here.
def index(request):

    if request.method=="POST":
        form=EmployeeForm(request.POST)

        if form.is_valid():
            form.save() #persist data in database, using queryset(Django ORM API) method==> create
            return redirect('../show')
        else:
            pass
    else:
        obj=EmployeeForm() #GET request, Empty form
        return render(request,'index.html',{'emp':obj}) #HTTP GET method for displaying empty form

def show(request):
    #name="TTL"
    employees=Employee.objects.all()
    return render(request,"show.html",{'emp_list':employees})

def edit(request, id):
    emp= Employee.objects.get(id=id)  # select *from students where id=id

    return render(request, 'edit.html', {'emp': emp})

def update(request, id):
    emp = Employee.objects.get(id=id)

    form = EmployeeForm(request.POST, instance=emp)

    if form.is_valid():
        form.save()
        return redirect('show')

    return render(request, 'edit.html', {'emp': emp})


def destroy(request, id):
    emp = Employee.objects.get(id=id)

    emp.delete()

    return redirect('../show')


